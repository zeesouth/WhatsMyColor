var dbConfig = {
  host: "hostname",
  port: 0000, //port num
  user: "username",
  password: "password",
  database: "databasename",
};

module.exports = dbConfig;
